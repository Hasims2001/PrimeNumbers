// Part 2 - Prime Number Generator Server

// Using the code from part 1 as the generation engine, write a server application (in the same programming language as above) giving the user the chance to use your prime number generator over a REST API over HTTP (API frameworks/libraries are allowed and encouraged) .
// For all users, record each execution in a database, including timestamp, range, time elapsed, algorithm chosen and number of primes returned.
// For simplicity of implementation, you can use an in-memory database, like (for example) HSQLDB.
package main
import(
	"fmt"
    "log"
    "net/http"
    "index.html"
	// "strings"
    // "strconv"
    // "math"
)

var ranges string
var splited []string

func main(){

	http.Handle("/", http.FileServer(http.Dir("./static")))
 
   

    port := ":8000"
    fmt.Println("Server is running on : http://localhost" + port)
 
    log.Fatal(http.ListenAndServe(port, nil))


    
}
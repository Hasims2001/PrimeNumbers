package main
import(
	"fmt"
  "strings"
  "strconv"
  "math"
)

var ranges string
var splited []string

func main(){

	fmt.Print("Enter Range (like, 2-10) : ")
	fmt.Scan(&ranges)
	
if strings.Contains(ranges, "-"){
	splited := strings.Split(ranges, "-")
	var nums = make([]int, len(splited))

	for idx, i := range splited {
        j, err := strconv.Atoi(i)
        if err != nil {
            panic(err)
        }
        nums[idx] = j
    }

	if nums[0]<2 || nums[1]<2{
		fmt.Println("Numbers must be greater than 2.")
	}else{
		fmt.Printf("-: Prime Numbers Between %d to %d :-\n", nums[0], nums[1])
		for nums[0] <= nums[1] {
			isPrime := true
			for i:=2; i<=int(math.Sqrt(float64(nums[0]))); i++{
			   if nums[0] % i == 0{
				  isPrime = false
				  break
			   } 
			}
			if isPrime {
			   fmt.Printf("\t\t %d \n", nums[0])
			}
			nums[0] += 1;
		 }
	}
}else{
	fmt.Println("Please Enter '-' Between Two Numbers Without Whitespace.")
}
}
